<?php
session_start();
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<link rel='icon' type='image/png' href="images/favicon.icon.png"/>
<title>Login</title>
<meta name="keywords" content="" />
<meta name="description" content="" />
<link href="default.css" rel="stylesheet" type="text/css" media="all" />
</head>
<body>
<div id="wrapper">
	<div id="header-wrapper">
		<div id="header" class="container">
			<div id="logo">
				<h1><a href="index.html">Hotel and Restaurant DSS</a></h1>
				<p>Eat Out and Sleep Out</p>
			</div>
			<div id="banner"> <a href="#" class="image"><img src="images/pic01.jpg" alt="" /></a> </div>
		</div>
	</div>
	<div id="menu-wrapper">
		<div id="menu" class="container">
			<ul>
				<li><a href="index.html">Home</a></li>
				<li><a href="about.php">About</a></li>
				<li><a href="contact.php">Contact</a></li>
				<li><a href="register.php">Sign Up</a></li>
				<li><a href="login.php">Sign In</a></li>
			</ul>
		</div>
	</div>
	<div id="portfolio-wrapper">
		<div id="portfolio" class="container">
	<div id="page" class="container">
		<div id="content">
			<div class="title">
				<h2>Sign in to proceed</h2></div>
<table width="100%" border="0" background="images/babyblue.png"
  <tr>
  <th scope="col">
  <form method="post" action="login.php">
<p align="center" class="style1"> Username: <br><input type="text" name="Username"</p></br>
<p align="center" class="style1"> Password:<br> <input type="password" name="Password" </p></br>
<p align="center" class="style1"> <input type= "submit" name="submit" value="Sign In"</p> </br>
<p align="right" class="style1"><p><a href="Admin/adminlogin.php">Login as Admin</p>
</form> 
</th>
</tr>
</table>
<?php
$host = "localhost";
$user = "root";
$pass = "";
$db = "hrdss1";

if (isset($_GET['logout'])){ 
	session_unset();
	session_destroy();
	header("Location:index.html");
}

$dbcon= mysqli_connect($host, $user, $pass);
mysqli_select_db($dbcon, $db);

if (isset ($_POST['Username'])){
$username = $_POST['Username'];
$password = $_POST['Password'];
$hash_p=sha1($password);

$sql = "SELECT * FROM user WHERE user_username = '".$username."' AND user_password = '".$hash_p. "' LIMIT 1";

$res = mysqli_query($dbcon, $sql) or die(mysqli_error($dbcon));
if (mysqli_num_rows ($res) == 1){
$_SESSION['currentuser'] = $username;
header("Location:profile.php");
exit();
}
else {
header("Location:login2.php");
exit();
}
}
?>
		</div>
		<div id="sidebar">
			<div class="box2">
				<div class="title">
					<h2></h2>
					<img src="images/login.png"/>
				</div>
			</div>
		</div>
	</div>
</div>

</div>
<div id="copyright" class="container">
	<p>&copy; HnR DSS. All rights reserved.| Design by Shirley Wanjiku</p>
</div>
</body>
</html>
