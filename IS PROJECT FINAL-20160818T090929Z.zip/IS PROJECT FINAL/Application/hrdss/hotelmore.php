<?php
		require_once('connect/connect.php'); 
		if(isset($_GET['id'])){
			$id=$_GET['id'];
			echo $id;
		}
		?>
		
	<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<link rel='icon' type='image/png' href="images/favicon.icon.png"/>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Hotel Search</title>
<meta name="keywords" content="" />
<meta name="description" content="" />
<link href="default.css" rel="stylesheet" type="text/css" media="all" />
</head>
<body>
<div id="wrapper">
	<div id="header-wrapper">
		<div id="header" class="container">
			<div id="logo">
				<h1><a href="index.html">Hotel and Restaurant DSS</a></h1>
				<p>Eat Out and Sleep Out</p>
			</div>
			<div id="banner"> <a href="#" class="image"><img src="images/pic01.jpg" alt="" /></a> </div>
		</div>
	</div>
	<div id="menu-wrapper">
		<div id="menu" class="container">
			<ul>
				<ul>
			    <li><a href="profile.php">Profile</a></li>
				<li><a href="restaurant.php">Restaurant</a></li>
			    <li><a href="hotel.php">Hotel</a></li>
				<li><a href="logout.php">Sign Off</a></li>	
			</ul>
			</ul>
		</div>
	</div>
<div id="page" class="container">
		<div id="content">
		<div class="box2">
				<div class="title">
					<h2></h2>
					
					<img src="images/kem10.jpg" width="800" height="490">
				</div>
			</div>
			<div class="title">
			<?php
			$query=mysqli_query($con, "SELECT * FROM hotel WHERE hotel_id=$id") or die(mysqli_error($con));
			$result=mysqli_fetch_assoc($query);
			$desc=$result['hotel_description'];
			$name=$result['hotel_name'];
			echo '
				<h2>'.$name.'</h2>
			<p>'.$desc.'</p>';
			?>
		</div>
		<div id="sidebar">
			
		</div>
	</div>