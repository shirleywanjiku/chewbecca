<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<link rel='icon' type='image/png' href="images/favicon.icon.png"/>
<title>Restaurant</title>
<meta name="keywords" content="" />
<meta name="description" content="" />
<link href="default.css" rel="stylesheet" type="text/css" media="all" />
</head>
<body>
<div id="wrapper">
	<div id="header-wrapper">
		<div id="header" class="container">
			<div id="logo">
				<h1><a href="index.html">Hotel and Restaurant DSS</a></h1>
				<p>Eat Out and Sleep Out</p>
			</div>
			<div id="banner"> <a href="#" class="image"><img src="images/pic01.jpg" alt="" /></a> </div>
		</div>
	</div>
	<div id="menu-wrapper">
		<div id="menu" class="container">
			<ul>
			    <li><a href="profile.php">Profile</a></li>
			    <li><a href="restaurant.php">Restaurant</a></li>
				<li><a href="hotel.php">Hotel</a></li>
				<li><a href="logout.php">Sign Off</a></li>	
			</ul>
			<?php 
session_start();
if (isset($_SESSION['currentuser'])){
echo "Hello" ."<br>".$_SESSION['currentuser'];
}
else
header("Location:login2.php"); 
?>
			</div></div>
	<div id="page" class="container">
<div id="content">
			<div class="title">
				<h2> Restaurant Offers</h2></div>
		<img src="images/bigsq.jpg" width="500" height="500" /> </br></br>
		<p>  <strong>Big Square Kenya offer all wednesdays</strong></p></br>
		<img src="images/12711133_1748413608726471_7640804511768329735_o.jpg" width="500" height="500"/></br></br>
		<p> <strong>Ocean Basket Kenya is selling Sashimi, Nigiri & Maki sushi at Half-price everyday 4-7PM, this is Happy hour redefined</strong>.</p> 
		</div>
		<div id="sidebar">
			<div class="box2">
				<div class="title">
					<h2></h2>
				</div><br>
				<img src="images/The_Good_Food_Guide_logo-280x255.gif"/>
				<ul><br>
				<li><a href="rselection.php">RESTAURANT SELECTION</a></li></br>
				<li><a href="rfeedback.php">YOUR REVIEWS AND RATINGS</a></li></br>
				</ul>
			</div>
		</div>
	</div>
</div>

</div>
<div id="copyright" class="container">
	<p>&copy; HnR DSS. All rights reserved.| Design by Shirley Wanjiku</p>
</div>
</body>
</html>