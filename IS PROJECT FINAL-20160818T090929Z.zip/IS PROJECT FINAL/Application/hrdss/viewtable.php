<?php
include('connect/connect.php');
$hotel_pricerange=$_GET['pricerange'];
$hotel_rating=$_GET['ratingname'];
$hotel_location=$_GET['location'];

   $sel=mysql_query("select * from hotel where hotel_pricerange='$hotel_pricerange', hotel_rating=$hotel_rating and hotel_location='$hotel_location'");
    while($arr=mysql_fetch_array($sel))
   {
			  echo
			   "<form method='post'>
			   <table border='1' align='center'>
					<tr>
					<td>
					<font size='+1'><b>Description</b></font>
					</td>
					</tr>";
			echo
			"<tr>
			<td><b>Price Range:</b>".$arr['hotel_pricerange'].
			"<br><b>Rating:</b>".$arr['hotel_rating'].
			"<br><b>Location:</b>".$arr['hotel_location'].
			"<br><b>Name:</b>".$arr['hotel_name'].
			"<br><b>Description:</b>".$arr['hotel_description'].
  "<br><br><input type='checkbox' name='c1[]' value='$arr[date]'/><b>Delete</b>
   </td>
   </tr></table>";
   
    }
	echo "<center><input type='submit' name='del' value='Delete'/></center></form>";
		
 
  ?>