<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<link rel='icon' type='image/png' href="images/favicon.icon.png"/>
<title>Hotel</title>
<meta name="keywords" content="" />
<meta name="description" content="" />
<link href="default.css" rel="stylesheet" type="text/css" media="all" />
</head>
<body>
<div id="wrapper">
	<div id="header-wrapper">
		<div id="header" class="container">
			<div id="logo">
				<h1><a href="index.html">Hotel and Restaurant DSS</a></h1>
				<p>Eat Out and Sleep Out</p>
			</div>
			<div id="banner"> <a href="#" class="image"><img src="images/pic01.jpg" alt="" /></a> </div>
		</div>
	</div>
	<div id="menu-wrapper">
		<div id="menu" class="container">
			<ul>
			    <li><a href="profile.php">Profile</a></li>
				<li><a href="restaurant.php">Restaurant</a></li>
			    <li><a href="hotel.php">Hotel</a></li>
				<li><a href="logout.php">Sign Off</a></li>	
			</ul>
			<?php 
session_start();
if (isset($_SESSION['currentuser'])){
echo "Hello" ."<br>".$_SESSION['currentuser'];
}
else
header("Location:login2.php"); 
?>
		</div></div>
<div id="page" class="container">
<div id="content">
<div class="title">
				<h2>Hotel News and Offers</h2></div>
		<img src="images/9cd5cb75-5b8d-4691-97ed-90a4c5bea1ec-large.jpeg" width="500" height="500" /> </br> </br>
		<p>  <strong>A new hotel coming up in Nairobi with a unique architectural style, elegant decor, personalized service and affordable top quality facilities for your accommodation, meeting, leisure and culinary needs.
Amber Hotel's 109 air-conditioned rooms and suites offer luxury accommodation in Nairobi in an elegant and contemporary style, thus well placed to host conferences and business meetings,
in addition to small groups, couples and families.

Amber Hotel is situated in a quiet corner on Ngong Lane, off Ngong Road with easy access to; popular shopping malls like Prestige Plaza, Yaya Centre and The Junction;
Nairobi Business Park; Health Centres and Golf Courses.</strong></p></br>
		</div>
		<div id="sidebar">
			<div class="box2">
				<div class="title">
					<h2></h2>
				</div><br>
				<img src="images/the_hotel_network_logo_design_2_by_icondesigns-d5bardw.jpg" width="400" height="200"/>
				<ul><br>
				<li><a href="hselection.php">HOTEL SELECTION</a></li></br>
				<li><a href="hfeedback.php">YOUR REVIEWS AND RATINGS</a></li></br>
				</ul>
			</div>
		</div>
	</div>
</div>

</div>
<div id="copyright" class="container">
	<p>&copy; HnR DSS. All rights reserved.| Design by Shirley Wanjiku</p>
</div>
</body>
</html>