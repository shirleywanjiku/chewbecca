<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<link rel='icon' type='image/png' href="images/favicon.icon.png"/>
<title>Contact</title>
<meta name="keywords" content="" />
<meta name="description" content="" />
<link href="default.css" rel="stylesheet" type="text/css" media="all" />
</head>
<body>
<div id="wrapper">
	<div id="header-wrapper">
		<div id="header" class="container">
			<div id="logo">
				<h1><a href="index.html">Hotel and Restaurant DSS</a></h1>
				<p>Eat Out and Sleep Out</p>
			</div>
			<div id="banner"> <a href="#" class="image"><img src="images/pic01.jpg" alt="" /></a> </div>
		</div>
	</div>
	<div id="menu-wrapper">
		<div id="menu" class="container">
			<ul>
				<li><a href="index.html">Home</a></li>
				<li><a href="about.php">About</a></li>
				<li><a href="contact.php">Contact</a></li>
				<li><a href="register.php">Sign Up</a></li>
				<li><a href="login.php">Sign In</a></li>
			</ul>
		</div>
	</div>
	<div id="portfolio-wrapper">
		<div id="portfolio" class="container">
	<div id="page" class="container">
		<div id="content">
			<div class="title">
				<h2>For any enquiries or clarifications feel free to contact us on:</h2></div>
<p><a href="https://twitter.com/hnr_dss">  Follow us on Twitter </a></p>
<p> <a href="https://www.facebook.com/hotelier.restaurante"> Our Facebook Page</a></p>
<p> Postal Address: PO BOX 45673 00800 Nairobi Kenya</p>
<p> <a href="mailto:ciikushirley@gmail.com"> Send us an email</a></p>
<p> Telephone Numbers: 0707123987, 0733123987, 0800123987 </p>
		</div>
		<div id="sidebar">
			<div class="box2">
				<div class="title">
					<h2></h2>
					<img src="images/2012082221223123-contact_us.jpg" />
				</div>
			</div>
		</div>
	</div>
</div>

</div>
<div id="copyright" class="container">
	<p>&copy; HnR DSS. All rights reserved.| Design by Shirley Wanjiku</p>
</div>
</body>
</html>
