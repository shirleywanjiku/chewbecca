<?php require_once('connect/connect.php'); ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<link rel='icon' type='image/png' href="images/favicon.icon.png"/>
<title>Restaurant Selection</title>
<meta name="keywords" content="" />
<meta name="description" content="" />
<link href="default.css" rel="stylesheet" type="text/css" media="all" />
</head>
<body>
<div id="wrapper">
	<div id="header-wrapper">
		<div id="header" class="container">
			<div id="logo">
				<h1><a href="index.html">Hotel and Restaurant DSS</a></h1>
				<p>Eat Out and Sleep Out</p>
			</div>
			<div id="banner"> <a href="#" class="image"><img src="images/pic01.jpg" alt="" /></a> </div>
		</div>
	</div>
	<div id="menu-wrapper">
		<div id="menu" class="container">
			<ul>
			    <li><a href="profile.php">Profile</a></li>
				<li><a href="restaurant.php">Restaurant</a></li>
			    <li><a href="hotel.php">Hotel</a></li>
				<li><a href="logout.php">Sign Off</a></li>	
			</ul>
			</div>
	</div>
	<div id="portfolio-wrapper">
		<div id="portfolio" class="container">
	<div id="page" class="container">
		<div id="content">
			<div class="title">
				<h2>Select Your Preferences</h2></div>
<table width="100%" align="center"  border="0" background="images/babyblue.png">
  <tr>
  <th scope="col">
  <script type="text/javascript" src="http://maps.google.com/maps/api/js?sensor=true"></script>
    <article>

    </article>
<script>
function success(position) {
  var mapcanvas = document.createElement('div');
  mapcanvas.id = 'mapcontainer';
  mapcanvas.style.height = '400px';
  mapcanvas.style.width = '600px';

  document.querySelector('article').appendChild(mapcanvas);

  var coords = new google.maps.LatLng(position.coords.latitude, position.coords.longitude);
  
  var options = {
    zoom: 15,
    center: coords,
    mapTypeControl: false,
    navigationControlOptions: {
    	style: google.maps.NavigationControlStyle.SMALL
    },
    mapTypeId: google.maps.MapTypeId.ROADMAP
  };
  var map = new google.maps.Map(document.getElementById("mapcontainer"), options);

  var marker = new google.maps.Marker({
      position: coords,
      map: map,
      title:"You are here!"
  });
}

if (navigator.geolocation) {
  navigator.geolocation.getCurrentPosition(success);
} else {
  error('Geo Location is not supported');
}

</script>
</br> </br> 
<form action="foundhotel.php" method="post" >
<p align="left">Price Range:
					
<select name="price">
<?php
	$query1= mysqli_query($con, "SELECT * FROM rpricerange") or die (mysqli_error($con));
	while($results=mysqli_fetch_array($query1)){
	$price=$results['rpricerange_name'];
	echo "<option value= $price ?> $price </option>";
  

}
?> 
</select> </br>

<p align="left">Cuisine Type:
<select name="cuisine">
<?php
	$query2= mysqli_query($con, "SELECT * FROM cuisine") or die (mysqli_error($con));
	while($results1=mysqli_fetch_array($query2)){
	$rate=$results1['cuisine_name'];
	echo "<option value= $rate ?> $rate </option>";
  

}
?> 

</select > </br>
					 
<p align="left">Select Area: <select name="area">
<?php
	$query3= mysqli_query($con, "SELECT * FROM area") or die (mysqli_error($con));
	while($results2=mysqli_fetch_array($query3)){
	$area=$results2['area_name'];
	echo "<option value= $area ?> $area </option>";
  

}
?> 
</select></p> </br></br>

<p align="center" class="style1"> <input type= "submit" name="submit" value="submit" required></p> </br>
</th>
</tr>
</table>
</div>
		<div id="sidebar">
			<div class="box2">
				<div class="title">
					<h2></h2>
				</div><br>
				<img src="images/The_Good_Food_Guide_logo-280x255.gif"/>
				<ul><br>
				<li><a href="restaurant.php">RESTAURANT NEWS AND OFFERS</a></li></br>
				<li><a href="rfeedback.php">YOUR REVIEWS AND RATINGS</a></li></br>
				<li><a href="rselection.php">RESTAURANT SELECTION</a></li></br>
				</ul>
			</div>
		</div>
	</div>
</div>

</div>
<div id="copyright" class="container">
	<p>&copy; HnR DSS. All rights reserved.| Design by Shirley Wanjiku</p>
</div>
</body>
</html>
					 						
											
