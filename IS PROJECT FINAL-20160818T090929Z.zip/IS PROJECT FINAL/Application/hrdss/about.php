<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<link rel='icon' type='image/png' href="images/favicon.icon.png"/>
<title>About</title>
<meta name="keywords" content="" />
<meta name="description" content="" />
<link href="default.css" rel="stylesheet" type="text/css" media="all" />
</head>
<body>
<div id="wrapper">
	<div id="header-wrapper">
		<div id="header" class="container">
			<div id="logo">
				<h1><a href="index.html">Hotel and Restaurant DSS</a></h1>
				<p>Eat Out and Sleep Out</p>
			</div>
			<div id="banner"> <a href="#" class="image"><img src="images/pic01.jpg" alt="" /></a> </div>
		</div>
	</div>
	<div id="menu-wrapper">
		<div id="menu" class="container">
			<ul>
				<li><a href="index.html">Home</a></li>
				<li><a href="about.php">About Us</a></li>
				<li><a href="contact.php">Contact</a></li>
				<li><a href="register.php">Sign Up</a></li>
				<li><a href="login.php">Sign In</a></li>
			</ul>
		</div>
	</div>
	<div id="portfolio-wrapper">
		<div id="portfolio" class="container">
	<div id="page" class="container">
		<div id="content">
			<div class="title">
				<h2>What We Do</h2></div>
			<p> This is a Hotel and Restaurant Decison Support System that will allow users to select Hotels and Restaurants according to their prefered preferences. Some of these preferences include location, the type of cuisine you like, rating and ranking of the hotels. We also consider the financial standards of the user therefore everyone can use the system. </p>
	<p> It is an easy to use system with the following steps: </p>
	<p> 1. Create an account and verify your email</p>
	<p> 2. Afterwards you can choose your prefernces of the place you have in mind to visit </p>
	<p> 3. Sit down and relax as we process your preferences and also  as we inform if there are any special offers or discounts </p>
	<p> 4. Choose the place you prefer the most from the selection we have given you back </p>
	<p> 5. Give us a feedback and review of the place once you have visited </p>
	<p> 6. Share the news on your social media platforms </p>
	<p> 7. You can repeat steps 2 to 6 again and again if you like what we do! </p>
		</div>
		<div id="sidebar">
			<div class="box2">
				<div class="title">
					<h2></h2>
				</div>
				<img src="images/doing-things-better.jpg" />
			</div>
		</div>
	</div>
</div>

</div>
<div id="copyright" class="container">
	<p>&copy; HnR DSS. All rights reserved.| Design by Shirley Wanjiku</p>
</div>
</body>
</html>
