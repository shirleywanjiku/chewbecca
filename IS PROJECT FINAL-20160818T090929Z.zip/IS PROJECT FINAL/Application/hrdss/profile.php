<?php 
include('connect/connect.php');
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<link rel='icon' type='image/png' href="images/favicon.icon.png"/>
<title>Profile Page</title>
<meta name="keywords" content="" />
<meta name="description" content="" />
<link href="default.css" rel="stylesheet" type="text/css" media="all" />
</head>
<body>
<div id="wrapper">
	<div id="header-wrapper">
		<div id="header" class="container">
			<div id="logo">
				<h1><a href="index.html">Hotel and Restaurant DSS</a></h1>
				<p>Eat Out and Sleep Out</p>
			</div>
			<div id="banner"> <a href="#" class="image"><img src="images/pic01.jpg" alt="" /></a> </div>
		</div>
	</div>
	<div id="menu-wrapper">
		<div id="menu" class="container">
			<ul>
			    <li><a href="profile.php">Profile</a></li>
				<li><a href="restaurant.php">Restaurant</a></li>
				<li><a href="hotel.php">Hotel</a></li>
				<li><a href="logout.php">Sign Off</a></li>	
			</ul>
			<?php 
session_start();
if (isset($_SESSION['currentuser'])){
	$gotuser=$_SESSION['currentuser'];
echo "Hello" ."<br>".$_SESSION['currentuser'];
}
else
header("Location:login2.php"); 
?>
		</div>
	</div>
	<div id="portfolio-wrapper">
		<div id="portfolio" class="container">
	<div id="page" class="container">
		<div id="content">
			<div class="title">
				<h2>Your Profile </h2></div>
				
<?php require_once("connect/connect.php");?>
<?php
$sql= mysqli_query($con,"SELECT *  FROM user WHERE `user_username`='$gotuser' ") or die(mysqli_error($con));
while($row=mysqli_fetch_assoc($sql)){
$id=$row['user_id'];
$fname=$row['user_firstname'];
$lname=$row['user_lastname'];
$tel=$row['user_telephone'];
$loc=$row['user_location'];
$email=$row['user_email'];
$username=$row['user_username'];
}  
?>
    <table width="100%" align="center"  border="0" background="images/babyblue.png">
      <tr>
        <td width="82" valign="top"><div align="left">FirstName:</div></td>
        <td width="165" valign="top"><?php echo $fname ?></td>
      </tr>
      <tr>
        <td valign="top"><div align="left">LastName:</div></td>
        <td valign="top"><?php echo $lname ?></td>
      </tr>
      <tr>
        <td valign="top"><div align="left">Username: </div></td>
        <td valign="top"><?php echo $username ?></td>
      </tr>
      <tr>
        <td valign="top"><div align="left">Email:</div></td>
        <td valign="top"><?php echo $email ?></td>
      </tr>
      <tr>
        <td valign="top"><div align="left">Telephone No.: </div></td>
        <td valign="top"><?php echo $tel ?></td>
      </tr>
      <tr>
        <td valign="top"><div align="left">Location:</div></td>
        <td valign="top"><?php echo $loc ?></td>
      </tr>
    </table>
		</div>
		<div id="sidebar">
			<div class="box2">
				<div class="title">
				<img src="images/user.png" />
					<ul> </br>
					<li><a href="edituser.php?id= <?php echo $id ?> ">Edit Your Profile</a></li></br>
					<li><a href="deleteuser.php?id= <?php echo $id ?>">Delete Your Profile</a></li>
					</ul>
				</div>
			</div>
		</div>
	</div>
</div>

</div>
<div id="copyright" class="container">
	<p>&copy; HnR DSS. All rights reserved.| Design by Shirley Wanjiku</p>
</div>
</body>
</html>