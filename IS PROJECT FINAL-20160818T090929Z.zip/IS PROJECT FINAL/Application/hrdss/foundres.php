<?php
		require_once('connect/connect.php'); 
		?>
		
	<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<link rel='icon' type='image/png' href="images/favicon.icon.png"/>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Hotel Search</title>
<meta name="keywords" content="" />
<meta name="description" content="" />
<link href="default.css" rel="stylesheet" type="text/css" media="all" />
</head>
<body>
<div id="wrapper">
	<div id="header-wrapper">
		<div id="header" class="container">
			<div id="logo">
				<h1><a href="index.html">Hotel and Restaurant DSS</a></h1>
				<p>Eat Out and Sleep Out</p>
			</div>
			<div id="banner"> <a href="#" class="image"><img src="images/pic01.jpg" alt="" /></a> </div>
		</div>
	</div>
	<div id="menu-wrapper">
		<div id="menu" class="container">
			<ul>
				<ul>
			    <li><a href="profile.php">Profile</a></li>
				<li><a href="restaurant.php">Restaurant</a></li>
			    <li><a href="hotel.php">Hotel</a></li>
				<li><a href="logout.php">Sign Off</a></li>	
			</ul>
			</ul>
		</div>
	</div>
	<div id="portfolio-wrapper">
		<div id="portfolio" class="container">
			<h2> Your Hotel search results</h2>
			
			<?php
		if(isset($_POST["price"]) AND ($_POST["rating"]) AND ($_POST["area"])){
		$price= $_POST["price"];
		$rating= $_POST["rating"];
		$area=$_POST["area"];
		
		$query=mysqli_query($con, "SELECT * FROM hotel WHERE (hotel_location LIKE '%{$area}%' AND hotel_rating LIKE '%{$rating}%' 
											AND hotel_pricerange LIKE '%{$price}%') ") or die (mysqli_error($con));
		if(mysqli_num_rows($query)>0){
		while($results=mysqli_fetch_array($query)){
			
			$resname=$results["hotel_name"];
			$resimage=$results["hotel_name"];
			$resid=$results["hotel_id"];
			$resdescrip=$results["hotel_description"];
			echo '
			<div id="column1">
			
				<div class="title">
					<h2>'.$resname. '</h2>
				</div>
				<a href="#" class="image image-full"><img src="Hotel Images/10010671_27_z.jpg" alt="" /></a>
				<p>'.substr($resdescrip, 0, 100).' ... <a href="hotelmore.php?id='.$resid.'">Read more</a></p>
				</div>
			';
		}
		}
		else{
			
			echo "We did not find anything that matches";
		}
		}
		else{
			echo "Please enter search paramteres";
		}
		
		
		?>
	
		</div>
	<?php
		
	
?>