<?php 
session_start();
if (isset($_SESSION['currentuser'])){
echo "Hello" ."<br>".$_SESSION['currentuser'];
}
else
header("Location:login2.php"); 
?>

<?php
require("connect/connect.php");
include('connect/connect.php');
if(isset($_GET['id'])){
	
	$id=$_GET['id'];
	
}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<link rel='icon' type='image/png' href="images/favicon.icon.png"/>
<title>Edit User Details</title>
<meta name="keywords" content="" />
<meta name="description" content="" />
<link href="default.css" rel="stylesheet" type="text/css" media="all" />
</head>
<body>
<div id="wrapper">
	<div id="header-wrapper">
		<div id="header" class="container">
			<div id="logo">
				<h1><a href="index.html">Hotel and Restaurant DSS</a></h1>
				<p>Eat Out and Sleep Out</p>
			</div>
			<div id="banner"> <a href="#" class="image"><img src="images/pic01.jpg" alt="" /></a> </div>
		</div>
	</div>
	<div id="menu-wrapper">
		<div id="menu" class="container">
			<ul>
			    <li><a href="profile.php">Profile</a></li>
				<li><a href="restaurant.php">Restaurant</a></li>
				<li><a href="hotel.php">Hotel</a></li>
				<li><a href="logout.php">Sign Off</a></li>	
			</ul>
		</div>
	</div>
	<div id="portfolio-wrapper">
		<div id="portfolio" class="container">
	<div id="page" class="container">
		<div id="content">
			<div class="title">
				<h2>Edit User Details for <?php echo $id ?> </h2></div>
<table width="100%" align="center"  border="0" background="images/babyblue.png">
<tr>
<?php

$query1=mysqli_query($con, "SELECT * FROM `user` WHERE user_id= $id ") or die(mysqli_error($con));
$result=mysqli_fetch_assoc($query1) or die(mysqli_error($con));
if(!$query1){
	echo "No";
}
else {
	echo $result['user_firstname'];
}


$fname=$result['user_firstname'];
$lname=$result['user_lastname'];
$email=$result['user_email'];
$username=$result['user_username'];
$tel=$result['user_telephone'];
$loc=$result['user_location'];
echo '
 <form action="#" method="post" >
<p align="justify" class="style1"> First Name: <br>  <input type="text" name="fname" value="'.$fname.'"required>
<p align="justify" class="style1"> Last Name:<br> <input type="text" name="lname" value="'.$lname.'"required > </p>
<p align="justify" class="style1"> Email:<br> <input type= "email" name="email" value="'.$email.'"required> </p>
<p align="justify" class="style1"> Username: <br> <input type="text" name="username" value="'.$username.'"required></p>
<p align="justify" class="style1"> Telephone: <br><input type="tel" name="telephone" value="'.$tel.'"required> </p>
<p align="justify" class="style1"> Location: <br><input type="text" name="location" value="'.$loc.'"required ></p>
<p align="justify" class="style1"> <input type= "submit" name="submit" value="submit" required></p>
</form> ';

if(isset($_POST['submit'])){
$fname=$_POST['fname'];
$lname=$_POST['lname'];
$email=$_POST['email'];
$username=$_POST['username'];
$tel=$_POST['telephone'];
$loc=$_POST['location'];
$query1=mysqli_query($con, "UPDATE`user` SET user_username='$username', user_firstname='$fname', user_lastname='$lname', user_email='$email', user_Location='$loc', 
								user_telephone='$tel' WHERE user_id=$id");
							
							if(!$query1){
							
							echo "Cannot add user" . mysqli_error($con);
							}
							else{
							
							header("Location:profile.php");
							}

}


?>
</th>
</tr>
</table>
		</div>
		<div id="sidebar">
			<div class="box2">
				<div class="title">
				<img src="images/user.png" />
					<ul></br> 
					<li><a href="profile.php">Your Profile</a></li></ul>
					<li><a href="deleteuser.php?id= <?php echo $id ?>">Delete Your Profile</a></li></br>
				</div>
			</div>
		</div>
	</div>
</div>

</div>
<div id="copyright" class="container">
	<p>&copy; HnR DSS. All rights reserved.| Design by Shirley Wanjiku</p>
</div>
</body>
</html>
