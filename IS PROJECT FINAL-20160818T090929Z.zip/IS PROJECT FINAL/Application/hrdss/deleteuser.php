
<?php require_once('connect/connect.php');
if(isset($_GET['id'])){
	
	$id=$_GET['id'];
	echo $id;
}

$query1=mysqli_query($con, "DELETE  FROM `user` WHERE user_id= $id" );


if(!$query1){
 	echo 'could not delete' . mysqli_error($con);
}
else {
	header("Location:index.html");
}
?>
