
<?php 
session_start();
if (isset($_SESSION['currentuser'])){
echo "Hello" ."<br>".$_SESSION['currentuser'];
}
else
header("Location:login2.php"); 
?>
<?php require_once('connect/connect.php');
if(isset($_GET['id'])){
	
	$id=$_GET['id'];
	echo $id;
}

$query1=mysqli_query($con, "DELETE  FROM `user` WHERE user_id= $id" );


if(!$query1){
 	echo 'could not delete' . mysqli_error($con);
}
else {
	header("Location:view users.php");
}
?>
