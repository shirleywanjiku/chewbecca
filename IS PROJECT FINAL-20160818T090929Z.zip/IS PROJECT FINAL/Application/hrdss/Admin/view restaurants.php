<?php 
include('connect/connect.php');
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<link rel='icon' type='image/png' href="../images/favicon.icon.png"/>
<title>Restaurant Information Saved</title>
<meta name="keywords" content="" />
<meta name="description" content="" />
<link href="default.css" rel="stylesheet" type="text/css" media="all" />
</head>
<body>
<div id="wrapper">
	<div id="header-wrapper">
		<div id="header" class="container">
			<div id="logo">
				<h1><a href="index.html">Hotel and Restaurant DSS</a></h1>
				<p>Eat Out and Sleep Out</p>
			</div>
			<div id="banner"> <a href="#" class="image"><img src="images/pic01.jpg" alt="" /></a> </div>
		</div>
	</div>
	<div id="menu-wrapper">
		<div id="menu" class="container">
			<ul>
			    <li><a href="index.php">Admin Home</a></li>
				<li><a href="view users.php">Users</a></li>
				<li><a href="view hotels.php">Hotels</a></li>
				<li><a href="view restuarnts.php">Restaurants</a></li>
				<li><a href="logout.php">Sign Off</a></li>
			</ul>
			<?php 
session_start();
if (isset($_SESSION['currentuser'])){
echo "Hello" ."<br>".$_SESSION['currentuser'];
}
else
header("Location:login2.php"); 
?>
		</div>
	</div>
	<div id="portfolio-wrapper">
		<div id="portfolio" class="container">
	<div id="page" class="container">
		<div id="content">
			<div class="title">
				<h2>Restaurant Information Stored</h2></div>
<table width="100%" align="center"  border="0" background="images/babyblue.png">
<tr>
  <th scope="col"></th>
  </tr>
  <tr>
  <th>Restaurant Name</th>
  <th>Location</th>
  <th>Type Of Cuisine</th>
  <th>Price Range</th>
  <th>Email</th>
  <th>Telephone</th>
  <th>Edit</th>
  <th>Delete</th>
  </tr>
<?php
$sql= mysqli_query($con,"SELECT * FROM restaurant") or die(mysqli_error($con));
while($row=mysqli_fetch_assoc($sql)){
$id=$row['restaurant_id'];
$rname=$row['restaurant_name'];
$loc=$row['restaurant_location'];
$cuisine=$row['restaurant_cuisinetype'];
$range=$row['restaurant_pricerange'];
$email=$row['restaurant_email'];
$tel=$row['restaurant_telephone'];  

echo '<tr>
  <td>'.$rname.'</td>
  <td>'.$loc.'</td>
  <td>'.$cuisine.'</td>
  <td>'.$range.'</td>
   <td>'.$email.'</td>
  <td>'.$tel.'</td>
  
  <td><a href="editrestaurant.php?id='.$id.'">Edit</a></td>
  <td><a href="deleterestaurant.php?id='.$id.'">Delete</a></td>
  </tr>';
}
?>
</tr>
</table>
		</div>
		<div id="sidebar">
			<div class="box2">
				<div class="title">
					<ul> <li><a href="create restaurant.php">Create Restaurant</a></li></ul>
				</div>
			</div>
		</div>
	</div>
</div>

</div>
<div id="copyright" class="container">
	<p>&copy; HnR DSS. All rights reserved.| Design by Shirley Wanjiku</p>
</div>
</body>
</html>