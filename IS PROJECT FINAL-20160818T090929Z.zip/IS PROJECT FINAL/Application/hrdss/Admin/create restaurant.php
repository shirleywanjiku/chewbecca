<?php ob_start(); ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<?php require_once("connect/connect.php");?>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<link rel='icon' type='image/png' href="../images/favicon.icon.png"/>
<title>Create Restaurant</title>
<meta name="keywords" content="" />
<meta name="description" content="" />
<link href="default.css" rel="stylesheet" type="text/css" media="all" />
</head>
<body>
<div id="wrapper">
	<div id="header-wrapper">
		<div id="header" class="container">
			<div id="logo">
				<h1><a href="index.html">Hotel and Restaurant DSS</a></h1>
				<p>Eat Out and Sleep Out</p>
			</div>
			<div id="banner"> <a href="#" class="image"><img src="images/pic01.jpg" alt="" /></a> </div>
		</div>
	</div>
	<div id="menu-wrapper">
		<div id="menu" class="container">
			<ul>
			    <li><a href="index.php">Admin Home</a></li>
				<li><a href="view users.php">Users</a></li>
				<li><a href="view hotels.php">Hotels</a></li>
				<li><a href="view restaurants.php">Restaurants</a></li>
				<li><a href="logout.php">Sign Off</a></li>
			</ul>
			<?php 
session_start();
if (isset($_SESSION['currentuser'])){
echo "Hello" ."<br>".$_SESSION['currentuser'];
}
else
header("Location:login2.php"); 
?>
		</div>
	</div>
	<div id="portfolio-wrapper">
		<div id="portfolio" class="container">
	<div id="page" class="container">
		<div id="content">
			<div class="title">
				<h2>Create Restaurant</h2></div>
				<table width="100%" align="center"  border="0" background="images/babyblue.png">
  <tr>
  <th scope="col">
  <form action="create restaurant.php" method="post" >
  <fieldset>
  <legend><h3 align="center"> Please Fill in the details below</h3> </legend> </br>
<p align="left" class="style1">Restaurant Name: <br>  <input type="text" name="Rname" required> </p>
<p align="left" class="style1">Location: <br>  
<select name="area_name" align="left" class="style1">
<?php
	$query3= mysqli_query($con, "SELECT * FROM area") or die (mysqli_error($con));
	while($results2=mysqli_fetch_array($query3)){
	$area=$results2['area_name'];
	echo "<option value= $area ?> $area </option>";
  

}
?> 
</select>
<p align="left" class="style1">Type of Cuisine: <br>  <input type="text" name="Cuisine" required> </p>
<p align="left" class="style1">Price Range: <br>  
<select name="Range" align="left" class="style1">
<?php
	$query5= mysqli_query($con, "SELECT * FROM rpricerange") or die (mysqli_error($con));
	while($results5=mysqli_fetch_array($query5)){
	 echo "<option value='" . $results5['rpricerange_name'] . "'>" . $results5['rpricerange_name'] . "</option>";
	
  

}
?> 
</select>
<p align="left" class="style1"> Email:<br> <input type= "email" name="Email" required> </p>
<p align="left" class="style1"> Telephone: <br><input type="tel" name="Telephone" required> </p>
<p align="center" class="style1"> <input type= "submit" name="submit" value="submit" required></p>
</form>
<?php 
if(isset($_POST['submit'])){
$rname=$_POST['Rname'];
$loc=$_POST['area_name'];
$cuisine=$_POST['Cuisine'];
$range=$_POST['Range'];
$email=$_POST['Email'];
$tel=$_POST['Telephone'];




$query1=mysqli_query($con, "INSERT INTO `restaurant` (restaurant_name, restaurant_location, restaurant_cuisinetype, restaurant_pricerange, restaurant_email, restaurant_telephone)
							VALUES ('$rname','$loc','$cuisine','$range', '$email', '$tel')");
							
							if(!$query1){
							
							echo "Cannot add restaurant" . mysqli_error($con);
							}
							else{
							
							header("Location:view restaurants.php");
							}
}
?> 
</th>
</tr>
</table>
		</div>
		<div id="sidebar">
			<div class="box2">
				<div class="title">
					<ul><li><a href="view restaurants.php">View Restaurants</a></li></ul>
				</div>
			</div>
		</div>
	</div>
</div>

</div>
<div id="copyright" class="container">
	<p>&copy; HnR DSS. All rights reserved.| Design by Shirley Wanjiku</p>
</div>
</body>
</html>
