<?php 
session_start();
if (isset($_SESSION['currentuser'])){
echo "Hello" ."<br>".$_SESSION['currentuser'];
}
else
header("Location:login2.php"); 
?>
<?php require_once('connect/connect.php');
if(isset($_GET['id'])){
	
	$id=$_GET['id'];
	echo $id;
}

$query1=mysqli_query($con, "DELETE  FROM `restaurant` WHERE restaurant_id= $id" );

if(!$query1){
 	echo 'could not delete restaurant' . mysqli_error($con);
}
else {
	echo "<script>
		confirm('Are you sure you want to delete')
	</script>";
	header("Location:view restaurants.php");
}
?>
