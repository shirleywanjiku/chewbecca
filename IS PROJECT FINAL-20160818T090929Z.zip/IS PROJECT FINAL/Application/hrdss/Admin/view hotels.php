<?php 
include('connect/connect.php');
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<link rel='icon' type='image/png' href="../images/favicon.icon.png"/>
<title>Hotel Information Saved</title>
<meta name="keywords" content="" />
<meta name="description" content="" />
<link href="default.css" rel="stylesheet" type="text/css" media="all" />
</head>
<body>
<div id="wrapper">
	<div id="header-wrapper">
		<div id="header" class="container">
			<div id="logo">
				<h1><a href="index.html">Hotel and Restaurant DSS</a></h1>
				<p>Eat Out and Sleep Out</p>
			</div>
			<div id="banner"> <a href="#" class="image"><img src="images/pic01.jpg" alt="" /></a> </div>
		</div>
	</div>
	<div id="menu-wrapper">
		<div id="menu" class="container">
			<ul>
			    <li><a href="index.php">Admin Home</a></li>
				<li><a href="view users.php">Users</a></li>
				<li><a href="view hotels.php">Hotels</a></li>
				<li><a href="view restaurants.php">Restaurants</a></li>
				<li><a href="logout.php">Sign Off</a></li>
			</ul>
			<?php 
session_start();
if (isset($_SESSION['currentuser'])){
echo "Hello" ."<br>".$_SESSION['currentuser'];
}
else
header("Location:login2.php"); 
?>

		</div>
	</div>
	<div id="portfolio-wrapper">
		<div id="portfolio" class="container">
	<div id="page" class="container">
		<div id="content">
			<div class="title">
				<h2>Hotel Information Stored</h2></div>
<table width="100%" align="center"  border="0" background="images/babyblue.png">
<tr>
  <th scope="col"></th>
  </tr>
  <tr>
  <th>Hotel Name</th>
  <th>Location</th>
  <th>Email</th>
  <th>Telephone</th>
  <th>Rating</th>
  <th>Price Range</th>
  <th>Edit</th>
  <th>Delete</th>
  </tr>
<?php
$sql= mysqli_query($con,"SELECT * FROM hotel") or die(mysqli_error($con));
while($row=mysqli_fetch_assoc($sql)){
$id=$row['hotel_id'];
$hname=$row['hotel_name'];
$loc=$row['hotel_location'];
$email=$row['hotel_email'];
$tel=$row['hotel_telephone']; 
$rating=$row['hotel_rating'];
$range=$row['hotel_pricerange'];

 

echo '<tr>
  <td>'.$hname.'</td>
  <td>'.$loc.'</td>
  <td>'.$email.'</td>
  <td>'.$tel.'</td>
  <td>'.$rating.'</td>
  <td>'.$range.'</td>
   

  
  <td><a href="edithotel.php?id='.$id.'">Edit</a></td>
  <td><a href="deletehotel.php?id='.$id.'">Delete</a></td>
  </tr>';
}
?>
</th>
</tr>
</table>
		</div>
		<div id="sidebar">
			<div class="box2">
				<div class="title">
					<ul> <li><a href="create hotel.php">Create Hotel</a></li></ul>
				</div>
			</div>
		</div>
	</div>
</div>

</div>
<div id="copyright" class="container">
	<p>&copy; HnR DSS. All rights reserved.| Design by Shirley Wanjiku</p>
</div>
</body>
</html>
