<?php ob_start(); ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<?php require_once("connect/connect.php");?>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<link rel='icon' type='image/png' href="images/favicon.icon.png"/>
<title>Register</title>
<meta name="keywords" content="" />
<meta name="description" content="" />
<link href="default.css" rel="stylesheet" type="text/css" media="all" />
</head>
<body>
<div id="wrapper">
	<div id="header-wrapper">
		<div id="header" class="container">
			<div id="logo">
				<h1><a href="index.html">Hotel and Restaurant DSS</a></h1>
				<p>Eat Out and Sleep Out</p>
			</div>
			<div id="banner"> <a href="#" class="image"><img src="images/pic01.jpg" alt="" /></a> </div>
		</div>
	</div>
	<div id="menu-wrapper">
		<div id="menu" class="container">
			<ul>
				<li><a href="index.html">Home</a></li>
				<li><a href="about.php">About</a></li>
				<li><a href="contact.php">Contact</a></li>
				<li><a href="register.php">Sign Up</a></li>
				<li><a href="login.php">Sign In</a></li>
			</ul>
		</div>
	</div>
	<div id="portfolio-wrapper">
		<div id="portfolio" class="container">
	<div id="page" class="container">
		<div id="content">
			<div class="title">
				<h2>Create Your Profile</h2></div>
<table width="100%" align="center"  border="0" background="images/babyblue.png">
  <tr>
  <th scope="col">
  <form action="register.php" method="post" >
  <fieldset>
  <legend><h3 align="center"> Please Fill in the details below</h3> </legend> </br>
<p align="center" class="style1">First Name: <br>  <input type="text" name="fname" required> </p> 
<p align="center" class="style1"> Last Name:<br> <input type="text" name="Lname" required > </p>
<p align="center" class="style1"> Email:<br> <input type= "email" name="Email" required> </p>
<p align="center" class="style1"> Username: <br> <input type="text" name="Username" required></p>
<p align="center" class="style1"> Telephone: <br><input type="tel" name="Telephone" required> </p>
<p align="center" class="style1"> Password:<br> <input type="password" name="Password" required > </p>
<p align="center" class="style1"> Confirm Password:<br> <input type="password" name="R-password" required > </p>
<p align="center" class="style1"> Location:<br> 
<?php

$dbcon= mysqli_connect('localhost', 'root', '');
mysqli_select_db($dbcon, 'hrdss1');

$sql = "SELECT area_name FROM area";
$result = mysqli_query( $dbcon, $sql);

echo "<select name='area_name'>";
while ($row = mysqli_fetch_array($result)) {
    echo "<option value='" . $row['area_name'] . "'>" . $row['area_name'] . "</option>";
}
echo "</select>";

?>

<p align="center" class="style1"> <input type= "submit" name="submit" value="submit" required></p>
</form> 
<?php

if(isset($_POST['submit'])){
$fname=$_POST['fname'];
$lname=$_POST['Lname'];
$email=$_POST['Email'];
$username=$_POST['Username'];
$tel=$_POST['Telephone'];
$password=$_POST['Password'];
$repassword=$_POST['R-password'];
$hash_p=sha1($password);
$strpass=strlen($password);
$loc=$_POST['area_name'];


if($strpass <5){
	echo "Your password is weak and it is a candidate to possible hacking. Make sure your password is more than 5 characters";

}
else{




if($password==$repassword){

$query1=mysqli_query($con, "INSERT INTO `user` (user_username, user_firstname, user_lastname,  user_password, user_email, user_location, user_telephone)
							VALUES ('$username','$fname','$lname','$hash_p','$email','$loc','$tel')");
							
							if(!$query1){
							
							echo "Cannot add user" . mysqli_error($con);
							}
							else{
							
							header("Location: login.php");
							}
}
else {
	echo "Your password fields do no match. Please confirm";
}
}

}
?>
</th>
</tr>
</table>
		</div>
		<div id="sidebar">
			<div class="box2">
				<div class="title">
					<h2></h2>
					<img src="images/signup-button.jpg" />
				</div>
			</div>
		</div>
	</div>
</div>

</div>
<div id="copyright" class="container">
	<p>&copy; HnR DSS. All rights reserved.| Design by Shirley Wanjiku</p>
</div>
</body>
</html>
