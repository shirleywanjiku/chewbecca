
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<link rel='icon' type='image/png' href="images/favicon.icon.png"/>
<title>Log Out</title>
<meta name="keywords" content="" />
<meta name="description" content="" />
<link href="default.css" rel="stylesheet" type="text/css" media="all" />
</head>
<body>
<div id="wrapper">
	<div id="header-wrapper">
		<div id="header" class="container">
			<div id="logo">
				<h1><a href="index.html">Hotel and Restaurant DSS</a></h1>
				<p>Eat Out and Sleep Out</p>
			</div>
			<div id="banner"> <a href="#" class="image"><img src="images/pic01.jpg" alt="" /></a> </div>
		</div>
	</div>
	<div id="menu-wrapper">
		<div id="menu" class="container">
			<ul>
				<li><a href="profile.php">Profile</a></li>
				<li><a href="restaurant.php">Restaurant</a></li>
				<li><a href="hotel.php">Hotel</a></li>
				<li><a href="logout.php">Sign Off</a></li>
			</ul>
			<?php 
session_start();
if (isset($_SESSION['currentuser'])){
echo "Hello" ."<br>".$_SESSION['currentuser'];
}
else
header("Location:login2.php"); 
?>
		</div>
	</div>
	<div id="portfolio-wrapper">
		<div id="portfolio" class="container">
	<div id="page" class="container">
		<div id="content">
			<div class="title">
				<h2></h2></div>
<table width="100%" border="0" background="images/babyblue.png"
  <tr>
  <th scope="col"><p><a href='login.php?logout=1' > <strong>Click Here To Log Out</strong> </a></p></th>
</tr>
</table>
<?php
$host = "localhost";
$user = "root";
$pass = "";
$db = "hrdss1";

if (isset($_GET['logout'])){ 
	session_unset();
	session_destroy();
	header("Location:index.php");
}

$dbcon= mysqli_connect($host, $user, $pass);
mysqli_select_db($dbcon, $db);

if (isset ($_POST['Username'])){
$username = $_POST['Username'];
$password = $_POST['Password'];
$hash_p=sha1($password);

$sql = "SELECT * FROM user WHERE user_username = '".$username."' AND user_password = '".$hash_p. "' LIMIT 1";

$res = mysqli_query($sql) or die(mysql_error());
if (mysql_num_rows ($res) == 1){
$_SESSION['currentuser'] = $username;
header("Location:profile.php");
exit();
}
else {
header("Location:login2.php");
exit();
}
}
?>
		</div>
		<div id="sidebar">
			<div class="box2">
				<div class="title">
					<h2></h2>
					<img src="images/k16912188.jpg"/>
				</div>
			</div>
		</div>
	</div>
</div>

</div>
<div id="copyright" class="container">
	<p>&copy; HnR DSS. All rights reserved.| Design by Shirley Wanjiku</p>
</div>
</body>
</html>
